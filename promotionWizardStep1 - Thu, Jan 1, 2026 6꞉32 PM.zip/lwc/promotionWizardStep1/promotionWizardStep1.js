import { LightningElement, api } from 'lwc';
import { fromContext } from '@lwc/state';
//TODO FOR THE CHALLENGE: Import the module for the State Management
import promotionStateManager from 'c/promotionStateManager';

export default class PromotionWizardStep1 extends LightningElement {
    promotionState = fromContext(promotionStateManager);

    promotionName;

    connectedCallback(){
        this.promotionName = this.promotionState?.value?.promotionName;
    }

    handleChange(event) {
        this.promotionName = event.detail.value;
    }

    @api
    allValid(){
        console.log('promotionName: ' + this.promotionName);
       
        if(this.promotionName === undefined || this.promotionName === ''){
            return false;
        }
        console.log('setting state');
        console.log(this.promotionState.value);
        console.log(this.promotionState.value.productCount);
        //TODO FOR THE CHALLENGE: Update the promotion name in the state
        //Note: You can uncomment the below line and examine the logic :) 
        //this.promotionState.value.updatePromotionName(this.promotionName);
        this.promotionState.value.updatePromotionName(this.promotionName);
        console.log('setting state finished');
        console.log(this.promotionState.value);
        
        return true;
    }
}